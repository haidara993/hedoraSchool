import 'dart:convert';

import 'package:get/get.dart';
import 'package:madrasatymobile/helpers/http_helper.dart';
import 'package:madrasatymobile/helpers/shared_preferences_helper.dart';
import 'package:madrasatymobile/models/Announcement.dart';
import 'package:madrasatymobile/models/user.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AnnouncementViewModel extends GetxController {
  User? _user = new User();
  User? get user => _user;

  List<Announcement> _announcements = [];
  List<Announcement> get announcements => _announcements;

  String? caption;
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
  }

  getAnnouncements() async {
    _user = await SharedPreferencesHelper.getAccountFromLocal();
    SharedPreferences pref = await SharedPreferences.getInstance();
    var token = pref.getString("jwt");

    var rs = await HttpHelper.get(
        ANNOUNCEMENT_ENDPOINT + (_user?.divisionId.toString())!,
        bearerToken: token);

    if (rs == 200) {
      final res = jsonDecode(rs.body).cast<Map<String, dynamic>>();
      _announcements =
          res.map<Announcement>((json) => Announcement.fromJson(json)).toList();
      update();
    }
  }

  postAnnouncement() async {
    Map<String, dynamic> data = {
      "UserId": _user?.id,
      "Caption": caption,
      "UserPhotoUrl": _user?.photoUrl,
      "DisplayName": _user?.displayName,
      "DivisionId": _user?.divisionId,
      "StandardId": _user?.standardId,
      "TimeStamp": "",
      "PhotoUrl": "",
      "AnnouncementType": ""
    };
  }
}
