import 'dart:convert';
import 'dart:io';

import 'package:get/get.dart';
import 'package:madrasatymobile/helpers/http_helper.dart';
import 'package:madrasatymobile/helpers/shared_preferences_helper.dart';
import 'package:madrasatymobile/models/user.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileViewModel extends GetxController {
  User? _user = new User();
  User? get user => _user;

  DateTime? dateOfBirth;
  // UserType userType = UserType.Unkown;
  bool guardiansPanel = false;
  String path = 'default';
  // String tempPath = '';
  // final _scaffoldKey = GlobalKey<ScaffoldState>();

  String? name, enrollNo, dob, guardianName, bloodGroup, mobileNo;
  int? standard, division;

  // Rx<XFile>? file;

  // final ImagePicker _picker = ImagePicker();
  @override
  void onInit() {
    super.onInit();
    getUser();
  }

  ProfileViewModel() {
    getUser();
  }

  handletakephoto() async {
    Get.back();
    // final XFile? photo = await _picker.pickImage(source: ImageSource.camera);

    final tempDir = await getTemporaryDirectory();
    path = tempDir.path;
    // if (photo != null) {
    //   this.file?.value = photo;
    // }
  }

  handlechoosephoto() async {
    Get.back();
    // final XFile? image = await _picker.pickImage(source: ImageSource.gallery);

    final tempDir = await getTemporaryDirectory();
    // path = tempDir.path;
    // if (image != null) {
    //   this.file?.value = image;
    // }
  }

  getUser() async {
    _user = await SharedPreferencesHelper.getAccountFromLocal();
    name = _user?.displayName;
    enrollNo = _user?.enrollNo;
    guardianName = _user?.guardianName;
    bloodGroup = _user?.bloodGroup;
    mobileNo = _user?.phoneNumber;
    standard = _user?.standardId;
    division = _user?.divisionId;
    dob = _user?.dob;
    update();
  }

  setUserData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    if (bloodGroup!.isEmpty ||
        name!.isEmpty ||
        enrollNo!.isEmpty ||
        dob!.isEmpty ||
        guardianName!.isEmpty ||
        mobileNo!.isEmpty) {
      Get.snackbar("unvailed data", "You Need to fill all the details");
    } else {
      print(name);
      Map<String, dynamic> json = {
        "photoUrl": _user?.photoUrl,
        "email": _user?.email,
        "divisionId": division,
        "standardId": standard,
        "displayName": name,
        "dob": dob,
        "guardianName": guardianName,
        "bloodGroup": bloodGroup,
        "phoneNumber": mobileNo,
        "isVerified": _user?.isVerified,
        "enrollNo": _user?.enrollNo
      };

      var bearerToken = pref.getString('jwt');
      var rs = await HttpHelper.put(
          UPDATE_ENDPOINT + (_user?.id.toString())!, json,
          bearerToken: bearerToken);

      if (rs.statusCode == 200) {
        var jsonObject = jsonDecode(rs.body);
        var account = User.fromJson(jsonObject);
        _user = account;

        SharedPreferencesHelper.saveAcountToLocal(account);
        Get.snackbar("success", "Your data has been successfully updated");
        update();
      }
    }
  }
}
