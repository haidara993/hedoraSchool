import 'package:get/get.dart';
import 'package:madrasatymobile/helpers/shared_preferences_helper.dart';
import 'package:madrasatymobile/models/user.dart';

class HomeViewModel extends GetxController {
  String path = 'default';
}
