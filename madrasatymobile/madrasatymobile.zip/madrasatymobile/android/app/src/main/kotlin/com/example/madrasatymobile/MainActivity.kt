package com.example.madrasatymobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
